--
-- Database: `toko_komputer`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_pelanggan`
--

CREATE TABLE `data_pelanggan` (
  `no_plo` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `kota` varchar(50) NOT NULL,
  `ttl` varchar(50) NOT NULL,
  `usia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `data_pelanggan`
--

INSERT INTO `data_pelanggan` (`no_plo`, `nama`, `alamat`, `kota`, `ttl`, `usia`) VALUES
('P001', 'Aldi', 'Jl.Sawit No.4', 'Nganjuk', 'Nganjuk, 12-06-1979', 31),
('P002', 'Amun', 'Jln.Bambu Raya no.1', 'Tanggerang', 'Tanggerang, 13-02-1990', 29),
('P003', 'Sulam', 'Jln.Banglah No.3', 'Jambi', 'Jambi, 12-06-1979', 28),
('P004', 'Dada', 'Jln.Sini Aja No.4', 'Bogor', 'Bogor, 08-03-1995', 28),
('P005', 'Fenny', 'Jln.Yuk Kesini No.6', 'Serang', 'Serang, 20-04-1996', 26);

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_pesanan`
--

CREATE TABLE `detail_pesanan` (
  `no_pesanan` int(6) NOT NULL,
  `kode` varchar(6) NOT NULL,
  `jml_prd` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis_produk`
--

CREATE TABLE `jenis_produk` (
  `kode` varchar(3) NOT NULL,
  `nama` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jenis_produk`
--

INSERT INTO `jenis_produk` (`kode`, `nama`) VALUES
('ACC', 'ACCESSORIES'),
('CAB', 'CABLE'),
('CAS', 'CASSING'),
('CDR', 'CDROM'),
('FLP', 'Flopy'),
('MDB', 'Mainboard');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesanan`
--

CREATE TABLE `pesanan` (
  `no_pesanan` int(6) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `tgl_pesanan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pesanan`
--

INSERT INTO `pesanan` (`no_pesanan`, `nama`, `tgl_pesanan`) VALUES
(73087, 'Sulam', '2020-08-09'),
(166465, 'Amun', '2022-11-10'),
(635070, 'Aldi', '2022-05-18');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `kode` varchar(6) NOT NULL,
  `jenis` varchar(6) NOT NULL,
  `tipe` varchar(50) NOT NULL,
  `spesifikasi` text NOT NULL,
  `merk` varchar(20) NOT NULL,
  `harga_dist` int(11) NOT NULL,
  `harga_cust` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`kode`, `jenis`, `tipe`, `spesifikasi`, `merk`, `harga_dist`, `harga_cust`) VALUES
('MON048', 'MON', '(22inch/0,25/2048x1536)P.Flat(BNC)', 'TV', 'VIEWSONIC', 7155000, 8372800),
('PRN015', 'PRN', 'Epson LQ 2 180 Metrodata', 'Kulkas', 'Epson', 5319000, 6116850),
('UPS013', 'UPS', 'UPS APC SU 3000NET', 'Komputer', 'APC', 12870000, 14900898);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_pelanggan`
--
ALTER TABLE `data_pelanggan`
  ADD PRIMARY KEY (`no_plo`);

--
-- Indexes for table `jenis_produk`
--
ALTER TABLE `jenis_produk`
  ADD PRIMARY KEY (`kode`);

--
-- Indexes for table `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`no_pesanan`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`kode`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
